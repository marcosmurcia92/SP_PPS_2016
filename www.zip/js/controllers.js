angular.module('app.controllers', ['firebase', 'ngCordova'])

.controller('grillaCtrl', function($scope, $timeout) {


 });
