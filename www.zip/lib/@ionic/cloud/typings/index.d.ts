/// <reference path="custom/superagent.d.ts" />
/// <reference path="globals/es6-promise/index.d.ts" />
